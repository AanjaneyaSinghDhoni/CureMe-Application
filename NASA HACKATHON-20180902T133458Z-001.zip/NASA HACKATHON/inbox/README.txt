A Pen created at CodePen.io. You can find this one at https://codepen.io/phantomesse/pen/ymgxE.

 A quick design of an inbox using absolute positioning and padding to make a fixed width div float along with a 100% width div. Also uses ul/li dropdown for CSS styling.