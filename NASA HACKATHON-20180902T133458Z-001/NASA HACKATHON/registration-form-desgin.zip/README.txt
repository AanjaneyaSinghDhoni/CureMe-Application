A Pen created at CodePen.io. You can find this one at https://codepen.io/_shree33/pen/HeiBC.

 A general registration form design from where user can create his/her account on your site using his/her email address or using facebook or twitter account